#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFile>
#include<QMessageBox>
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<math.h>
#include <QTextStream>
#include <iostream>
#include <cstring>
#include <string.h>
#include <semaphore.h>
#include<sys/ioctl.h>
#include <sys/mman.h>

#define AX_AD7606_MAGIC 	'x'  //定义幻数
#define AX_AD7606_MAX_NR 	 2   //定义命令的最大序数，
//#define COMM_ALLOC_MEM 	  	_IO(AX_AD7606_MAGIC, 0)
#define COMM_GET_CURPAGENUM 	_IO(AX_AD7606_MAGIC, 1)
#define COMM_TEST			 	_IO(AX_AD7606_MAGIC, 0)



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

//    setGeometry(800, 480, 800, 480);

    InitShow();

    InitData();

}

void MainWindow::InitData()
{
    recvDevFd =open("/dev/ax_adc1",O_RDWR);
    if (0 >= recvDevFd)
    {
        QMessageBox::warning(this,"open device",QString::fromLocal8Bit("open device failed !"));
        return;
    }

    //for test
//    ioctl(recvDevFd, COMM_TEST);

    m_bepagenum  = 0;
    m_curpagenum = 0;
    m_pagecount  = 0;

    m_pShareMem = mmap(NULL, ADC_MEM_BUFF_SIZE,PROT_READ,MAP_SHARED, recvDevFd,0 );
    if( m_pShareMem == MAP_FAILED ) {
        printf("Error : getMemMsgBuf() fail mmap!\n");
//        return NULL;
    }



/*    recvBuff = (char*)malloc(READBUFF_LEN);
    if (NULL== recvBuff)
    {
        QMessageBox::warning(this,"malloc resource", QString::fromLocal8Bit("read alloc resource failed !"));
        return;
    }
*/
    recvFileTimer = new QTimer(this);
    connect( recvFileTimer, SIGNAL(timeout()), this, SLOT(Timer_RecvfromDev()));
    recvFileTimer->start(20);

}

void MainWindow::InitShow()
{
    ui->customPlot->setBackground(QBrush(Qt::black));
    ui->customPlot->yAxis->setLabelColor(Qt::white);
    ui->customPlot->xAxis->setLabelColor(Qt::white);
    ui->customPlot->xAxis->setBasePen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setBasePen(QPen(Qt::white, 1));
    ui->customPlot->xAxis->setTickLabelColor(Qt::white);
    ui->customPlot->yAxis->setTickLabelColor(Qt::white);
    ui->customPlot->xAxis->setTickPen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setTickPen(QPen(Qt::white, 1));
    ui->customPlot->xAxis->setSubTickPen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setSubTickPen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setTicks(true);
    ui->customPlot->yAxis->setSubTicks(true);
    ui->customPlot->yAxis->setPadding(20);
//    ui->customPlot->yAxis->setTickStep(0.1);
//    ui->customPlot->yAxis2->setTickLabels(true);

    ui->customPlot->yAxis->grid()->setSubGridVisible(true);
    ui->customPlot->xAxis->grid()->setSubGridVisible(true);

    QSharedPointer<QCPAxisTickerFixed> intTicker(new QCPAxisTickerFixed);
    intTicker->setTickStep(0.001);
    intTicker->setScaleStrategy(QCPAxisTickerFixed::ssMultiples);
    ui->customPlot->yAxis->setTicker(intTicker);

//    ui->customPlot->rescaleAxes();
//    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes );
    ui->customPlot->setInteractions( QCP::iSelectAxes );
    ui->customPlot->xAxis->setRange(0, 512);
    ui->customPlot->yAxis->setRange(-5, 5);
    ui->customPlot->axisRect()->setupFullAxesBox();

    ui->customPlot->xAxis->setLabel("t");
    ui->customPlot->yAxis->setLabel("V");
    ui->customPlot->legend->setVisible(false);

    connect(ui->customPlot, SIGNAL(axisDoubleClick(QCPAxis*,QCPAxis::SelectablePart,QMouseEvent*)), this, SLOT(axisLabelDoubleClick(QCPAxis*,QCPAxis::SelectablePart)));

    ui->customPlot->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->customPlot, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(contextMenuRequest(QPoint)));

    for(int i=0;i<CHAN_NUM+1;i++)
        bchanshow[i] = true;


    ui->chan1->setText("C1");
    ui->chan2->setText("C2");
    ui->chan3->setText("C3");
    ui->chan4->setText("C4");
    ui->chan5->setText("C5");
    ui->chan6->setText("C6");
    ui->chan7->setText("C7");
    ui->chan8->setText("C8");
    ui->chan9->setText("A");


    recvStop = false;

    axisup = 0.0f;
    axiszoom = 1.0f;
    axisupnum = 0;
    axiszoomnum = 0;

    ui->chan1->setStyleSheet("background-color: rgb(250,0,0);font-size:14px;color:black");
    ui->chan2->setStyleSheet("background-color: rgb(0,250,0);font-size:14px;color:black");
    ui->chan3->setStyleSheet("background-color: rgb(0,0,250);font-size:14px;color:black");
    ui->chan4->setStyleSheet("background-color: rgb(250,250,0);font-size:14px;color:black");
    ui->chan5->setStyleSheet("background-color: rgb(0,100,0);font-size:14px;color:black");
    ui->chan6->setStyleSheet("background-color: rgb(139,0,139);font-size:14px;color:black");
    ui->chan7->setStyleSheet("background-color: rgb(139,0,0);font-size:14px;color:black");
    ui->chan8->setStyleSheet("background-color: rgb(255,0,255);font-size:14px;color:black");

    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(0)->setPen(QPen(Qt::red));
    ui->customPlot->graph(0)->setName("chan1");



    ui->customPlot->addGraph();
    ui->customPlot->graph(1)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(1)->setPen(QPen(Qt::green));
    ui->customPlot->graph(1)->setName("chan2");

    ui->customPlot->addGraph();
    ui->customPlot->graph(2)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(2)->setPen(QPen(Qt::blue));
    ui->customPlot->graph(2)->setName("chan3");

    ui->customPlot->addGraph();
    ui->customPlot->graph(3)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(3)->setPen(QPen(Qt::yellow));
    ui->customPlot->graph(3)->setName("chan4");

    ui->customPlot->addGraph();
    ui->customPlot->graph(4)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(4)->setPen(QPen(Qt::darkYellow));
    ui->customPlot->graph(4)->setName("chan5");

    ui->customPlot->addGraph();
    ui->customPlot->graph(5)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(5)->setPen(QPen(Qt::darkMagenta));
    ui->customPlot->graph(5)->setName("chan6");

    ui->customPlot->addGraph();
    ui->customPlot->graph(6)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(6)->setPen(QPen(Qt::darkRed));
    ui->customPlot->graph(6)->setName("chan7");

    ui->customPlot->addGraph();
    ui->customPlot->graph(7)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(7)->setPen(QPen(Qt::magenta));
    ui->customPlot->graph(7)->setName("chan8");


}

MainWindow::~MainWindow()
{
    free(recvBuff);
    recvBuff = NULL;

    CloseDev(recvDevFd);
    recvDevFd = 0;

    delete ui;
}

void MainWindow::axisLabelDoubleClick(QCPAxis *axis, QCPAxis::SelectablePart part)
{
  if (part == QCPAxis::spAxisLabel)
  {
    bool ok;
    QString newLabel = QInputDialog::getText(this, "osci", "New axis label:", QLineEdit::Normal, axis->label(), &ok);
    if (ok)
    {
      axis->setLabel(newLabel);
      ui->customPlot->replot();
    }
  }

}

int MainWindow::RecvfromDev(char *cbuff, int len)
{
    int ret = 0;

    if ( (NULL == cbuff) || (0 >= len) )
    {
        return 0;
    }


    if (0 >= recvDevFd)
    {
        QMessageBox::warning(this,"recive from device",QString::fromLocal8Bit("recive device is error!"));
        return -1;
    }

    ret = read(recvDevFd, cbuff, len);

    return ret;
}

void MainWindow::Timer_RecvfromDev()
{
     int i = 0;
/*    int ret = 0;

    QString strValue;

    memset(recvBuff, 0, READBUFF_LEN);

    ret = this->RecvfromDev(recvBuff, READBUFF_LEN);

    if(ret<=0)
    {
        paintCnt = 0;
        return;
    }
    memcpy(paintBuff, recvBuff, ret);
    paintCnt = ret/2;

    if(paintCnt>0)
        DrawGraph();*/

     m_pagecount = 0;

     m_curpagenum = ioctl(recvDevFd, COMM_GET_CURPAGENUM,0);

    if(m_curpagenum>0)
        m_curpagenum --;


    if(m_bepagenum>m_curpagenum)
    {
        memcpy(memBuff, m_pShareMem + (m_bepagenum+1)*ADC_BUFF_SIZE, (ADC_MEM_PAGE_NUM-m_bepagenum-1)*ADC_BUFF_SIZE);

        m_pagecount = m_pagecount + ADC_MEM_PAGE_NUM-m_bepagenum-1;

        memcpy(memBuff+m_pagecount*ADC_BUFF_SIZE, m_pShareMem, (m_curpagenum+1)*ADC_BUFF_SIZE);

        m_pagecount = m_pagecount + m_curpagenum + 1;


    }else if(m_bepagenum < m_curpagenum)
    {
        memcpy(memBuff, m_pShareMem + (m_bepagenum+1)*ADC_BUFF_SIZE, (m_curpagenum-m_bepagenum)*ADC_BUFF_SIZE);

        m_pagecount = m_pagecount + m_curpagenum-m_bepagenum;


    }else{
        memcpy(memBuff, m_pShareMem + (m_curpagenum+1)*ADC_BUFF_SIZE, ADC_BUFF_SIZE);
        m_pagecount = 1;
    }


    m_bepagenum = m_curpagenum;

    memset(paintBuff, 0, QT_MAX_PKT_LEN*2);


    long size= (m_pagecount*ADC_BUFF_SIZE)<(QT_MAX_PKT_LEN*2)?(m_pagecount*ADC_BUFF_SIZE):(QT_MAX_PKT_LEN*2);
    if(size>0)
    {

        memcpy(paintBuff, memBuff, size);
        paintCnt = size/2;

/*        for(int i=0;i<32;i++)
        {
            if((i%8==2) || (i%8==6))
            printf("Recvf, i=%d,buf=%d\n", i, paintBuff[i]);
        }*/


        if(paintCnt>0)
            DrawGraph();
   }
}

void MainWindow::removeAllGraphs()
{
  ui->customPlot->clearGraphs();
  ui->customPlot->replot();
}

void MainWindow::CloseDev(int fd)
{
    if (0 >= fd)
    {
        return;
    }

    ::close(fd);
}

void MainWindow::DrawGraph()
{
    int n = paintCnt/CHAN_NUM;

    QVector<double> y0(n),y1(n), y2(n), y3(n), y4(n), y5(n), y6(n), y7(n);
    QVector<double> x0(n);


    for(int i=0;i<paintCnt;i++)
    {

        switch(i%CHAN_NUM)
        {
            case 0:
                {
                    int t = i/CHAN_NUM;
                    y0[t] = paintBuff[i]*5.0f/32768;
                    x0[t] = t;
                }

                break;
            case 1:
                y1[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;
                break;
            case 2:
                y2[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;
                break;
            case 3:
                y3[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;
                break;
            case 4:
                y4[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;
                break;
            case 5:
                y5[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;
                break;
            case 6:
                y6[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;
                break;
            case 7:
                y7[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;
                break;
            default:
                y0[i/CHAN_NUM] = paintBuff[i]*5.0f/32768;

        }

    }

    if(bchanshow[0])
    {
        ui->customPlot->graph(0)->setData(x0, y0);
        ui->customPlot->graph(0)->setVisible(true);
    }else{
        ui->customPlot->graph(0)->setVisible(false);
    }

    if(bchanshow[1])
    {
        ui->customPlot->graph(1)->setData(x0, y1);
        ui->customPlot->graph(1)->setVisible(true);
    }else{
        ui->customPlot->graph(1)->setVisible(false);
    }

    if(bchanshow[2])
    {
        ui->customPlot->graph(2)->setData(x0, y2);
        ui->customPlot->graph(2)->setVisible(true);
    }else{
        ui->customPlot->graph(2)->setVisible(false);
    }

    if(bchanshow[3])
    {
        ui->customPlot->graph(3)->setData(x0, y3);
        ui->customPlot->graph(3)->setVisible(true);
    }else{
        ui->customPlot->graph(3)->setVisible(false);
    }

    if(bchanshow[4])
    {
        ui->customPlot->graph(4)->setData(x0, y4);
        ui->customPlot->graph(4)->setVisible(true);
    }else{
        ui->customPlot->graph(4)->setVisible(false);
    }

    if(bchanshow[5])
    {
        ui->customPlot->graph(5)->setData(x0, y5);
        ui->customPlot->graph(5)->setVisible(true);
    }else{
        ui->customPlot->graph(5)->setVisible(false);
    }

    if(bchanshow[6])
    {
        ui->customPlot->graph(6)->setData(x0, y6);
        ui->customPlot->graph(6)->setVisible(true);
    }else{
        ui->customPlot->graph(6)->setVisible(false);
    }

    if(bchanshow[7])
    {
        ui->customPlot->graph(7)->setData(x0, y7);
        ui->customPlot->graph(7)->setVisible(true);
    }else{
        ui->customPlot->graph(7)->setVisible(false);
    }
    ui->customPlot->replot();
}

void MainWindow::on_chan1_clicked()
{
    bchanshow[0] = !bchanshow[0];
    if(bchanshow[0])
        ui->chan1->setText("C1");
    else
        ui->chan1->setText("c1");
}

void MainWindow::on_chan2_clicked()
{
    bchanshow[1] = !bchanshow[1];
    if(bchanshow[1])
        ui->chan2->setText("C2");
    else
        ui->chan2->setText("c2");

}

void MainWindow::on_chan3_clicked()
{
    bchanshow[2] = !bchanshow[2];
    if(bchanshow[2])
        ui->chan3->setText("C3");
    else
        ui->chan3->setText("c3");

}

void MainWindow::on_chan4_clicked()
{
    bchanshow[3] = !bchanshow[3];
    if(bchanshow[3])
        ui->chan4->setText("C4");
    else
        ui->chan4->setText("c4");

}

void MainWindow::on_chan5_clicked()
{
    bchanshow[4] = !bchanshow[4];
    if(bchanshow[4])
        ui->chan5->setText("C5");
    else
        ui->chan5->setText("c5");

}

void MainWindow::on_chan6_clicked()
{
    bchanshow[5] = !bchanshow[5];
    if(bchanshow[5])
        ui->chan6->setText("C6");
    else
        ui->chan6->setText("c6");
}

void MainWindow::on_chan7_clicked()
{
    bchanshow[6] = !bchanshow[6];
    if(bchanshow[6])
        ui->chan7->setText("C7");
    else
        ui->chan7->setText("c7");

}

void MainWindow::on_chan8_clicked()
{
    bchanshow[7] = !bchanshow[7];

    if(bchanshow[7])
        ui->chan8->setText("C8");
    else
        ui->chan8->setText("c8");
}

void MainWindow::on_chan9_clicked()
{
    bchanshow[8] = !bchanshow[8];

    if(bchanshow[8])
    {
        for(int i=0;i<8;i++)
        {
            bchanshow[i] = true;
        }

        ui->chan1->setText("C1");
        ui->chan2->setText("C2");
        ui->chan3->setText("C3");
        ui->chan4->setText("C4");
        ui->chan5->setText("C5");
        ui->chan6->setText("C6");
        ui->chan7->setText("C7");
        ui->chan8->setText("C8");
        ui->chan9->setText("A");
    }else
    {
        for(int i=0;i<8;i++)
        {
            bchanshow[i] = false;
        }

        ui->chan1->setText("c1");
        ui->chan2->setText("c2");
        ui->chan3->setText("c3");
        ui->chan4->setText("c4");
        ui->chan5->setText("c5");
        ui->chan6->setText("c6");
        ui->chan7->setText("c7");
        ui->chan8->setText("c8");
        ui->chan9->setText("a");
    }
}

void MainWindow::on_stop_clicked()
{

    recvStop = !recvStop;
    if(recvStop)
    {
        if(recvFileTimer!=NULL)
            recvFileTimer->stop();
    }else
    {
        if(recvFileTimer!=NULL)
            recvFileTimer->start(0);
    }
}

void MainWindow::on_zoomin_clicked()
{

/*    QWheelEvent wheelEvent(QPointF(5,5), 120, Qt::MidButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &wheelEvent);*/

    if(axiszoomnum<9)
    {
        ui->customPlot->yAxis->scaleRange(0.8f);//按比例因子缩放
        axiszoom = axiszoom*0.8f;
        ui->customPlot->replot();
        axiszoomnum++;
    }
}

void MainWindow::on_zoomout_clicked()
{
//    QWheelEvent wheelEvent(QPointF(5,5), -120, Qt::MidButton, Qt::NoModifier);
//    QCoreApplication::sendEvent(ui->customPlot, &wheelEvent);
    if(axiszoomnum>-6)
    {
        ui->customPlot->yAxis->scaleRange(1.25f);//按比例因子缩放
        axiszoom = axiszoom*1.25f;
        ui->customPlot->replot();
        axiszoomnum--;
    }
}

void MainWindow::on_up_clicked()
{
/*    QPoint pt=cursor().pos();//获取当前鼠标位置

    QMouseEvent mousePressEvent(QEvent::MouseButtonPress, QPointF(5,5), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mousePressEvent);

    QMouseEvent mouseMoveEvent(QEvent::MouseMove, QPointF(5,7), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseMoveEvent);

    QMouseEvent mouseReleaseEvent(QEvent::MouseButtonRelease, QPointF(5,7), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseReleaseEvent);

    QMouseEvent mouseMoveEvent1(QEvent::MouseMove, QPointF(5,5), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->up, &mouseMoveEvent1);*/


    ui->customPlot->yAxis->moveRange(0.5f);//移动坐标轴
    axisup = axisup + 0.5f;
    ui->customPlot->replot();
}

void MainWindow::on_down_clicked()
{
/*
    QMouseEvent mousePressEvent(QEvent::MouseButtonPress, QPointF(5,7), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mousePressEvent);

    QMouseEvent mouseMoveEvent(QEvent::MouseMove, QPointF(5,5), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseMoveEvent);

    QMouseEvent mouseReleaseEvent(QEvent::MouseButtonRelease, QPointF(5,5), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseReleaseEvent);

    QMouseEvent mouseMoveEvent1(QEvent::MouseMove, QPointF(5,5), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->up, &mouseMoveEvent1);*/
    ui->customPlot->yAxis->moveRange(-0.5f);//移动坐标轴
    axisup = axisup - 0.5f;
    ui->customPlot->replot();
}

void MainWindow::on_back_clicked()
{
    ui->customPlot->yAxis->moveRange(-axisup);//移动坐标轴
    ui->customPlot->yAxis->scaleRange(1/axiszoom);//按比例因子缩放
    axisup=0.0f;
    axiszoom = 1.0f;
    axiszoomnum = 0;
    ui->customPlot->replot();

}

