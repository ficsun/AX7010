#ifndef AXISFIXEDPIXELTICKER_H
#define AXISFIXEDPIXELTICKER_H


#include "qcustomplot.h"

class AxisFixedPixelTicker : public QCPAxisTicker
{
public:
    AxisFixedPixelTicker(QCPAxis * axis);
    ~AxisFixedPixelTicker();

public:
    void SetTickPixelStep(int pixel);//设置固定像素
    int GetTickPixelStep() const;//获取固定像素大小

protected:
    //QCPAxisTicker
    virtual double getTickStep(const QCPRange & range) override;//重写父类方法，根据固定像素返回步长值

private:
    QScopedPointer<AxisFixedPixelTicker> d_ptr;
};

#endif // AXISFIXEDPIXELTICKER_H
