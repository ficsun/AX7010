#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
//#include <QVector>

#include <QInputDialog>
#include <QTimer>
#define READBUFF_LEN 1024*8
#define CHAN_NUM     8
#define QT_MAX_PKT_LEN     (16384)

#define ADC_MEM_PAGE_NUM	128
#define ADC_BUFF_SIZE		16384
#define ADC_MEM_BUFF_SIZE ADC_BUFF_SIZE * ADC_MEM_PAGE_NUM
//#define COMM_GET_CURPAGENUM 1

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    double num[512];
    void Graph_Show(QCustomPlot *customPlot);

    void InitShow();
    void InitData();
    int  RecvfromDev(char *cbuff, int len);
    void CloseDev(int fd);
    void DrawGraph();

public slots:
    void on_chan1_clicked();
    void on_chan2_clicked();
    void on_chan3_clicked();
    void on_chan4_clicked();
    void on_chan5_clicked();
    void on_chan6_clicked();
    void on_chan7_clicked();
    void on_chan8_clicked();
    void on_chan9_clicked();

    void on_stop_clicked();
    void on_zoomin_clicked();
    void on_zoomout_clicked();
    void on_up_clicked();
    void on_down_clicked();
    void on_back_clicked();


    void axisLabelDoubleClick(QCPAxis* axis, QCPAxis::SelectablePart part);
    void removeAllGraphs();
    void Timer_RecvfromDev();
//    void contextMenuRequest(QPoint pos);
private:
    Ui::MainWindow *ui;

    bool  bchanshow[CHAN_NUM+1];
    int   recvDevFd;
    char  *recvBuff;
    QTimer *recvFileTimer;

    short paintBuff[QT_MAX_PKT_LEN];
    int   paintCnt;

    char memBuff[ADC_MEM_BUFF_SIZE];

    void *m_pShareMem;
    bool  recvStop;

    float   axisup;
    float   axiszoom;
    int     axisupnum;
    int     axiszoomnum;
    int     m_curpagenum;
    int     m_bepagenum;
    int     m_pagecount;
};

#endif // MAINWINDOW_H
