#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
//#include <QVector>

#include <QInputDialog>
#include <QTimer>
#define READBUFF_LEN 1024*8
#define CHAN_NUM     8
#define QT_MAX_PKT_LEN     (16384)

#define ADC_MEM_PAGE_NUM	128
#define ADC_BUFF_SIZE		16384
//#define ADC_BUFF_SIZE		8192
#define ADC_MEM_BUFF_SIZE ADC_BUFF_SIZE * ADC_MEM_PAGE_NUM
//#define COMM_GET_CURPAGENUM 1

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    double num[512];
    void Graph_Show(QCustomPlot *customPlot);

    void InitShow();
    void InitData();
    void CloseDev(int fd);
    void DrawGraph();

public slots:
    void on_chan1_clicked();
    void on_chan2_clicked();

    void on_stop_clicked();
    void on_zoomin_clicked();
    void on_zoomout_clicked();
    void on_up_clicked();
    void on_down_clicked();
    void on_back_clicked();

    void axisLabelDoubleClick(QCPAxis* axis, QCPAxis::SelectablePart part);
    void removeAllGraphs();
    void Timer_RecvfromDev1();
//    void contextMenuRequest(QPoint pos);
private:
    Ui::MainWindow *ui;

    bool  bchanshow[2];
    int   recvDevFd1;
    int   recvDevFd2;
    char  *recvBuff1;
    char  *recvBuff2;
    QTimer *recvFileTimer1;

    short paintBuff1[QT_MAX_PKT_LEN];
    short paintBuff2[QT_MAX_PKT_LEN];
    int   paintCnt1;
    int   paintCnt2;

    char  memBuff1[ADC_MEM_BUFF_SIZE];
    char  memBuff2[ADC_MEM_BUFF_SIZE];

    void *m_pShareMem1;
    void *m_pShareMem2;
    bool  recvStop;

    float   axisup;
    float   axiszoom;
    int     axisupnum;
    int     axiszoomnum;

    int     m_curpagenum1;
    int     m_bepagenum1;
    int     m_pagecount1;

    int     m_curpagenum2;
    int     m_bepagenum2;
    int     m_pagecount2;

};

#endif // MAINWINDOW_H
