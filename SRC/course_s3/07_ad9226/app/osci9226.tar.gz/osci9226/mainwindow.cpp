/*
 *  ad9226 application
 *
 *
 */

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFile>
#include<QMessageBox>
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<math.h>
#include <QTextStream>
#include <iostream>
#include <cstring>
#include <string.h>
#include <semaphore.h>
#include<sys/ioctl.h>
#include <sys/mman.h>

#define AX_ADC_MAGIC 	'x'  //定义幻数
#define AX_ADC_MAX_NR 	 2   //定义命令的最大序数，
#define COMM_ALLOC_MEM 	  	_IO(AX_ADC_MAGIC, 0)
#define COMM_GET_CURPAGENUM 	_IO(AX_ADC_MAGIC, 1)
#define COMM_TEST			 	_IO(AX_ADC_MAGIC, 0)

#define DISPLAY
#define DISPLAYPIXELS      512


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

//    setGeometry(800, 480, 800, 480);

    InitShow();

    InitData();

}

void MainWindow::InitData()
{

    recvDevFd1 =open("/dev/ax_adc1",O_RDWR);

    recvDevFd2 =open("/dev/ax_adc2",O_RDWR);

    if ((0 >= recvDevFd1) && (0 >= recvDevFd2))
    {
        QMessageBox::warning(this,"open device",QString::fromLocal8Bit("open device failed !"));
        return;
    }

    m_bepagenum1  = 0;
    m_curpagenum1 = 0;
    m_pagecount1  = 0;
    m_bepagenum2  = 0;
    m_curpagenum2 = 0;
    m_pagecount2  = 0;

    if(recvDevFd1>0)
    {
        m_pShareMem1 = mmap(NULL, ADC_MEM_BUFF_SIZE,PROT_READ,MAP_SHARED, recvDevFd1,0);
        if( m_pShareMem1 == MAP_FAILED ) {
            printf("Error : getMemMsgBuf() fail mmap!\n");
        }


    }

    if(recvDevFd2>0)
    {
       m_pShareMem2 = mmap(NULL, ADC_MEM_BUFF_SIZE,PROT_READ,MAP_SHARED, recvDevFd2,0 );
       if( m_pShareMem2 == MAP_FAILED ) {
           printf("Error : getMemMsgBuf() fail mmap!\n");
       }

    }

    recvFileTimer1 = new QTimer(this);
    connect( recvFileTimer1, SIGNAL(timeout()), this, SLOT(Timer_RecvfromDev1()));
    recvFileTimer1->start(50);

}

void MainWindow::InitShow()
{
    ui->customPlot->setBackground(QBrush(Qt::black));
    ui->customPlot->yAxis->setLabelColor(Qt::white);
    ui->customPlot->xAxis->setLabelColor(Qt::white);
    ui->customPlot->xAxis->setBasePen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setBasePen(QPen(Qt::white, 1));
    ui->customPlot->xAxis->setTickLabelColor(Qt::white);
    ui->customPlot->yAxis->setTickLabelColor(Qt::white);
    ui->customPlot->xAxis->setTickPen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setTickPen(QPen(Qt::white, 1));
    ui->customPlot->xAxis->setSubTickPen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setSubTickPen(QPen(Qt::white, 1));
    ui->customPlot->yAxis->setTicks(true);
    ui->customPlot->yAxis->setSubTicks(true);
    ui->customPlot->yAxis->setPadding(20);
//    ui->customPlot->yAxis->setTickStep(0.1);
//    ui->customPlot->yAxis2->setTickLabels(true);

    ui->customPlot->yAxis->grid()->setSubGridVisible(true);
    ui->customPlot->xAxis->grid()->setSubGridVisible(true);

    QSharedPointer<QCPAxisTickerFixed> intTicker(new QCPAxisTickerFixed);
    intTicker->setTickStep(0.001);
    intTicker->setScaleStrategy(QCPAxisTickerFixed::ssMultiples);
    ui->customPlot->yAxis->setTicker(intTicker);

//    ui->customPlot->rescaleAxes();
//    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes );
    ui->customPlot->setInteractions( QCP::iSelectAxes );
    ui->customPlot->xAxis->setRange(0, 512);
    ui->customPlot->yAxis->setRange(-5, 5);
    ui->customPlot->axisRect()->setupFullAxesBox();

    ui->customPlot->xAxis->setLabel("t");
    ui->customPlot->yAxis->setLabel("V");
    ui->customPlot->legend->setVisible(false);

    connect(ui->customPlot, SIGNAL(axisDoubleClick(QCPAxis*,QCPAxis::SelectablePart,QMouseEvent*)), this, SLOT(axisLabelDoubleClick(QCPAxis*,QCPAxis::SelectablePart)));

    ui->customPlot->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->customPlot, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(contextMenuRequest(QPoint)));

    for(int i=0;i<CHAN_NUM+1;i++)
        bchanshow[i] = true;

    recvStop = false;

    axisup = 0.0f;
    axiszoom = 1.0f;
    axisupnum = 0;
    axiszoomnum = 0;

    ui->chan1->setVisible(true);
    ui->chan2->setVisible(true);

    ui->chan1->setText("C1");
    ui->chan2->setText("C2");

    ui->chan1->setStyleSheet("background-color: rgb(250,0,0);font-size:14px;color:black");
    ui->chan2->setStyleSheet("background-color: rgb(0,250,0);font-size:14px;color:black");

    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(0)->setPen(QPen(Qt::red));
    ui->customPlot->graph(0)->setName("chan1");

    ui->customPlot->addGraph();
    ui->customPlot->graph(1)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->customPlot->graph(1)->setPen(QPen(Qt::green));
    ui->customPlot->graph(1)->setName("chan2");


}

MainWindow::~MainWindow()
{
    free(recvBuff1);
    recvBuff1 = NULL;

    free(recvBuff2);
    recvBuff2 = NULL;

    CloseDev(recvDevFd1);
    recvDevFd1 = 0;
    CloseDev(recvDevFd2);
    recvDevFd2 = 0;

    delete ui;
}

void MainWindow::axisLabelDoubleClick(QCPAxis *axis, QCPAxis::SelectablePart part)
{
  if (part == QCPAxis::spAxisLabel)
  {
    bool ok;
    QString newLabel = QInputDialog::getText(this, "osci", "New axis label:", QLineEdit::Normal, axis->label(), &ok);
    if (ok)
    {
      axis->setLabel(newLabel);
      ui->customPlot->replot();

    }
  }

}

void MainWindow::Timer_RecvfromDev1()
{
    m_pagecount1 = 0;
    m_curpagenum1 = ioctl(recvDevFd1, COMM_GET_CURPAGENUM,0);


    if(m_curpagenum1>0)
        m_curpagenum1 --;

#ifdef DISPLAY
    //DISPLAYPIXELS 512
    if(m_bepagenum1>m_curpagenum1)
    {
        memcpy(paintBuff1, m_pShareMem1 + (m_bepagenum1+1)*ADC_BUFF_SIZE, DISPLAYPIXELS * 2);
    }else if(m_bepagenum1 < m_curpagenum1)
    {
        memcpy(paintBuff1, m_pShareMem1 + (m_bepagenum1+1)*ADC_BUFF_SIZE, DISPLAYPIXELS * 2);
    }else{
        memcpy(paintBuff1, m_pShareMem1 + (m_curpagenum1+1)*ADC_BUFF_SIZE, DISPLAYPIXELS * 2);
    }

    m_bepagenum1 = m_curpagenum1;

    paintCnt1 = DISPLAYPIXELS;

#else
    //all data
    if(m_bepagenum1>m_curpagenum1)
    {
        memcpy(memBuff1, m_pShareMem1 + (m_bepagenum1+1)*ADC_BUFF_SIZE, (ADC_MEM_PAGE_NUM-m_bepagenum1-1)*ADC_BUFF_SIZE);
        m_pagecount1 = ADC_MEM_PAGE_NUM-m_bepagenum1-1;
        memcpy(memBuff1+m_pagecount1*ADC_BUFF_SIZE, m_pShareMem1, (m_curpagenum1+1)*ADC_BUFF_SIZE);
        m_pagecount1 = m_pagecount1 + m_curpagenum1 + 1;

    }else if(m_bepagenum1 < m_curpagenum1)
    {
        memcpy(memBuff1, m_pShareMem1 + (m_bepagenum1+1)*ADC_BUFF_SIZE, (m_curpagenum1-m_bepagenum1)*ADC_BUFF_SIZE);
        m_pagecount1 = m_curpagenum1-m_bepagenum1;
    }else{
        memcpy(memBuff1, m_pShareMem1 + (m_curpagenum1+1)*ADC_BUFF_SIZE, ADC_BUFF_SIZE);
        m_pagecount1 = 1;

    }

    m_bepagenum1 = m_curpagenum1;

/*    memset(paintBuff1, 0, QT_MAX_PKT_LEN*2);


    long size= (m_pagecount1*ADC_BUFF_SIZE)<(QT_MAX_PKT_LEN*2)?(m_pagecount1*ADC_BUFF_SIZE):(QT_MAX_PKT_LEN*2);
    if(size>0)
    {

        memcpy(paintBuff1, memBuff1, size);
        paintCnt1 = size/2;

   }*/
#endif


/////////////////////////////////////////////////////
#ifdef DISPLAY
    //DISPLAYPIXELS 512
    m_pagecount2 = 0;
    m_curpagenum2 = ioctl(recvDevFd2, COMM_GET_CURPAGENUM,1);

    if(m_curpagenum2>0)
        m_curpagenum2 --;


    if(m_bepagenum2>m_curpagenum2)
    {
        memcpy(paintBuff2, m_pShareMem2 + (m_bepagenum2+1)*ADC_BUFF_SIZE, DISPLAYPIXELS * 2);
    }else if(m_bepagenum2 < m_curpagenum2)
    {
        memcpy(paintBuff2, m_pShareMem2 + (m_bepagenum2+1)*ADC_BUFF_SIZE, DISPLAYPIXELS * 2);
    }else{
        memcpy(paintBuff2, m_pShareMem2 + (m_curpagenum2+1)*ADC_BUFF_SIZE, DISPLAYPIXELS * 2);
    }

    m_bepagenum2 = m_curpagenum2;

    paintCnt2 = DISPLAYPIXELS;

#else
    m_pagecount2 = 0;
    m_curpagenum2 = ioctl(recvDevFd2, COMM_GET_CURPAGENUM,1);

    if(m_curpagenum2>0)
        m_curpagenum2 --;


    if(m_bepagenum2>m_curpagenum2)
    {
        memcpy(memBuff2, m_pShareMem2 + (m_bepagenum2+1)*ADC_BUFF_SIZE, (ADC_MEM_PAGE_NUM-m_bepagenum2-1)*ADC_BUFF_SIZE);

        m_pagecount2 = m_pagecount2 + ADC_MEM_PAGE_NUM-m_bepagenum2-1;

        memcpy(memBuff2+m_pagecount2*ADC_BUFF_SIZE, m_pShareMem2, (m_curpagenum2+1)*ADC_BUFF_SIZE);

        m_pagecount2 = m_pagecount2 + m_curpagenum2 + 1;


    }else if(m_bepagenum2 < m_curpagenum2)
    {
        memcpy(memBuff2, m_pShareMem2 + (m_bepagenum2+1)*ADC_BUFF_SIZE, (m_curpagenum2-m_bepagenum2)*ADC_BUFF_SIZE);

        m_pagecount2 = m_pagecount2 + m_curpagenum2-m_bepagenum2;


    }else{
        memcpy(memBuff2, m_pShareMem2 + (m_curpagenum2+1)*ADC_BUFF_SIZE, ADC_BUFF_SIZE);
        m_pagecount2 = 1;
    }


    m_bepagenum2 = m_curpagenum2;

    memset(paintBuff2, 0, QT_MAX_PKT_LEN*2);

    size= (m_pagecount2*ADC_BUFF_SIZE)<(QT_MAX_PKT_LEN*2)?(m_pagecount2*ADC_BUFF_SIZE):(QT_MAX_PKT_LEN*2);
    if(size>0)
    {

        memcpy(paintBuff2, memBuff2, size);
        paintCnt2 = size/2;

   }

#endif

 //  if(paintCnt2>0)
 //       DrawGraph(2);
//    paintCnt1 = paintCnt1>paintCnt2?paintCnt1:paintCnt2;

   if(paintCnt1>0)
        DrawGraph();
}

void MainWindow::removeAllGraphs()
{
  ui->customPlot->clearGraphs();
  ui->customPlot->replot();
}

void MainWindow::CloseDev(int fd)
{
    if (0 >= fd)
    {
        return;
    }

    ::close(fd);
}

void MainWindow::DrawGraph()
{
    int size = 0;
    size = paintCnt1<512?paintCnt1:512;
    QVector<double> y0(size), y1(size);
    QVector<double> x0(size);
    for(int i=0;i<size;i++)
    {
        y0[i] = paintBuff1[i]*10.0f/4096;
        y1[i] = paintBuff2[i]*10.0f/4096;
        x0[i] = i;
    }

    if(bchanshow[0])
    {
        ui->customPlot->graph(0)->setData(x0, y0);
        ui->customPlot->graph(0)->setVisible(true);
    }else{
        ui->customPlot->graph(0)->setVisible(false);
    }

    if(bchanshow[1])
    {
        ui->customPlot->graph(1)->setData(x0, y1);
        ui->customPlot->graph(1)->setVisible(true);
    }else{
        ui->customPlot->graph(1)->setVisible(false);
    }

    ui->customPlot->replot();
}

void MainWindow::on_chan1_clicked()
{
    bchanshow[0] = !bchanshow[0];
    if(bchanshow[0])
        ui->chan1->setText("C1");
    else
        ui->chan1->setText("c1");
}

void MainWindow::on_chan2_clicked()
{
    bchanshow[1] = !bchanshow[1];
    if(bchanshow[1])
        ui->chan2->setText("C2");
    else
        ui->chan2->setText("c2");

}


void MainWindow::on_stop_clicked()
{

    recvStop = !recvStop;
    if(recvStop)
    {
        if(recvFileTimer1!=NULL)
            recvFileTimer1->stop();
    }else
    {
        if(recvFileTimer1!=NULL)
            recvFileTimer1->start(0);
    }
}

void MainWindow::on_zoomin_clicked()
{

/*    QWheelEvent wheelEvent(QPointF(5,5), 120, Qt::MidButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &wheelEvent);*/

    if(axiszoomnum<9)
    {
        ui->customPlot->yAxis->scaleRange(0.8f);//按比例因子缩放
        axiszoom = axiszoom*0.8f;
        ui->customPlot->replot();
        axiszoomnum++;
    }
}

void MainWindow::on_zoomout_clicked()
{
//    QWheelEvent wheelEvent(QPointF(5,5), -120, Qt::MidButton, Qt::NoModifier);
//    QCoreApplication::sendEvent(ui->customPlot, &wheelEvent);
    if(axiszoomnum>-6)
    {
        ui->customPlot->yAxis->scaleRange(1.25f);//按比例因子缩放
        axiszoom = axiszoom*1.25f;
        ui->customPlot->replot();
        axiszoomnum--;
    }
}

void MainWindow::on_up_clicked()
{
/*    QPoint pt=cursor().pos();//获取当前鼠标位置

    QMouseEvent mousePressEvent(QEvent::MouseButtonPress, QPointF(5,5), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mousePressEvent);

    QMouseEvent mouseMoveEvent(QEvent::MouseMove, QPointF(5,7), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseMoveEvent);

    QMouseEvent mouseReleaseEvent(QEvent::MouseButtonRelease, QPointF(5,7), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseReleaseEvent);

    QMouseEvent mouseMoveEvent1(QEvent::MouseMove, QPointF(5,5), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->up, &mouseMoveEvent1);*/


    ui->customPlot->yAxis->moveRange(0.5f);//移动坐标轴
    axisup = axisup + 0.5f;
    ui->customPlot->replot();
}

void MainWindow::on_down_clicked()
{
/*
    QMouseEvent mousePressEvent(QEvent::MouseButtonPress, QPointF(5,7), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mousePressEvent);

    QMouseEvent mouseMoveEvent(QEvent::MouseMove, QPointF(5,5), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseMoveEvent);

    QMouseEvent mouseReleaseEvent(QEvent::MouseButtonRelease, QPointF(5,5), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->customPlot, &mouseReleaseEvent);

    QMouseEvent mouseMoveEvent1(QEvent::MouseMove, QPointF(5,5), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
    QCoreApplication::sendEvent(ui->up, &mouseMoveEvent1);*/
    ui->customPlot->yAxis->moveRange(-0.5f);//移动坐标轴
    axisup = axisup - 0.5f;
    ui->customPlot->replot();
}

void MainWindow::on_back_clicked()
{
    ui->customPlot->yAxis->moveRange(-axisup);//移动坐标轴
    ui->customPlot->yAxis->scaleRange(1/axiszoom);//按比例因子缩放
    axisup=0.0f;
    axiszoom = 1.0f;
    axiszoomnum = 0;
    ui->customPlot->replot();

}

