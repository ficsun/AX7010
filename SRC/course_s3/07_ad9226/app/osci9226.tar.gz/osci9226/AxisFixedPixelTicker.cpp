
#include "AxisFixedPixelTicker.h"

double AxisFixedPixelTicker::getTickStep(const QCPRange & range) 
{
/*    if (d_ptr->m_pDependAxis)
    {
        bool vertical;
        if (d_ptr->m_pDependAxis->axisType() == QCPAxis::atLeft
            || d_ptr->m_pDependAxis->axisType() == QCPAxis::atRight)
        {
            vertical = true;
        }
        else
        {
            vertical = false;
        }

        int screenLength = vertical ? d_ptr->m_pDependAxis->axisRect()->rect().height() : d_ptr->m_pDependAxis->axisRect()->rect().width();
        return d_ptr->m_iPixel * range.size() / screenLength;
    }
    else
    {
        return __super::getTickStep(range);
    }*/
}
