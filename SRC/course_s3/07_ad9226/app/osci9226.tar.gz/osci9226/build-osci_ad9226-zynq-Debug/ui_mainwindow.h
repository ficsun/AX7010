/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QCustomPlot *customPlot;
    QPushButton *chan1;
    QPushButton *chan2;
    QPushButton *up;
    QPushButton *down;
    QPushButton *zoomin;
    QPushButton *zoomout;
    QPushButton *stop;
    QPushButton *back;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(800, 480);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        customPlot = new QCustomPlot(centralWidget);
        customPlot->setObjectName(QStringLiteral("customPlot"));
        customPlot->setGeometry(QRect(10, 10, 681, 460));
        chan1 = new QPushButton(centralWidget);
        chan1->setObjectName(QStringLiteral("chan1"));
        chan1->setGeometry(QRect(700, 20, 31, 31));
        chan1->setAutoFillBackground(false);
        chan2 = new QPushButton(centralWidget);
        chan2->setObjectName(QStringLiteral("chan2"));
        chan2->setGeometry(QRect(700, 60, 31, 31));
        chan2->setAutoFillBackground(false);
        up = new QPushButton(centralWidget);
        up->setObjectName(QStringLiteral("up"));
        up->setGeometry(QRect(750, 20, 41, 41));
        up->setStyleSheet(QStringLiteral("image: url(:/new/prefix1/up.ico);"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/new/prefix1/up.ico"), QSize(), QIcon::Normal, QIcon::Off);
        up->setIcon(icon);
        up->setIconSize(QSize(24, 24));
        down = new QPushButton(centralWidget);
        down->setObjectName(QStringLiteral("down"));
        down->setGeometry(QRect(750, 80, 41, 41));
        down->setStyleSheet(QStringLiteral("image: url(:/new/prefix1/down.ico);"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/new/prefix1/down.ico"), QSize(), QIcon::Normal, QIcon::Off);
        down->setIcon(icon1);
        down->setIconSize(QSize(24, 24));
        zoomin = new QPushButton(centralWidget);
        zoomin->setObjectName(QStringLiteral("zoomin"));
        zoomin->setGeometry(QRect(750, 140, 41, 41));
        zoomin->setStyleSheet(QStringLiteral("image: url(:/new/prefix1/zoomin.ico);"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/new/prefix1/zoomin.ico"), QSize(), QIcon::Normal, QIcon::Off);
        zoomin->setIcon(icon2);
        zoomin->setIconSize(QSize(24, 24));
        zoomout = new QPushButton(centralWidget);
        zoomout->setObjectName(QStringLiteral("zoomout"));
        zoomout->setGeometry(QRect(750, 200, 41, 41));
        zoomout->setStyleSheet(QStringLiteral("image: url(:/new/prefix1/zoomout.ico);"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/new/prefix1/zoomout.ico"), QSize(), QIcon::Normal, QIcon::Off);
        zoomout->setIcon(icon3);
        zoomout->setIconSize(QSize(24, 24));
        zoomout->setAutoRepeat(true);
        stop = new QPushButton(centralWidget);
        stop->setObjectName(QStringLiteral("stop"));
        stop->setGeometry(QRect(750, 260, 41, 41));
        stop->setStyleSheet(QStringLiteral("image: url(:/new/prefix1/pause.ico);"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/new/prefix1/pause.ico"), QSize(), QIcon::Normal, QIcon::Off);
        stop->setIcon(icon4);
        stop->setIconSize(QSize(24, 24));
        back = new QPushButton(centralWidget);
        back->setObjectName(QStringLiteral("back"));
        back->setGeometry(QRect(750, 320, 41, 41));
        back->setStyleSheet(QStringLiteral("image: url(:/new/prefix1/back.ico);"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/new/prefix1/back.ico"), QSize(), QIcon::Normal, QIcon::Off);
        back->setIcon(icon5);
        back->setIconSize(QSize(24, 24));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        chan1->setText(QApplication::translate("MainWindow", "c1", 0));
        chan2->setText(QApplication::translate("MainWindow", "c2", 0));
        up->setText(QString());
        down->setText(QString());
        zoomin->setText(QString());
        zoomout->setText(QString());
        stop->setText(QString());
        back->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
