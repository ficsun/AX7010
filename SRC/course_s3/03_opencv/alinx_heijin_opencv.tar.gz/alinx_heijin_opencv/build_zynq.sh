#!/bin/sh
source /opt/Xilinx/SDK/2015.4/settings64.sh
export CROSS_COMPILE=arm-xilinx-linux-gnueabi-
Cur_Dir=$(pwd)
export ZYNQ_CV_BUILD=$Cur_Dir/opencv_lib_zynq

export LD_LIBRARY_PATH=$ZYNQ_CV_BUILD/lib:${LD_LIBRARY_PATH}
export C_INCLUDE_PATH=$ZYNQ_CV_BUILD/include:${C_INCLUDE_PATH}
export CPLUS_INCLUDE_PATH=$ZYNQ_CV_BUILD/include:${CPLUS_INCLUDE_PATH}
export PKG_CONFIG_PATH=$ZYNQ_CV_BUILD/lib/pkgconfig:${PKG_CONFIG_PATH}
export PKG_CONFIG_LIBDIR=/opt/Xilinx/SDK/2015.4/gnu/arm/lin/arm-xilinx-linux-gnueabi/lib

cd $Cur_Dir/v4l-utils-1.12.5
make clean
./bootstrap.sh
./configure --prefix=$ZYNQ_CV_BUILD --host=arm-xilinx-linux-gnueabi --without-jpeg --with-udevdir=$ZYNQ_CV_BUILD/lib/udev
make
make install

cd $Cur_Dir/zlib-1.2.7
export CC=arm-xilinx-linux-gnueabi-gcc
./configure --prefix=$ZYNQ_CV_BUILD --shared
make
make install

cd $Cur_Dir/jpeg-8d
./configure --prefix=$ZYNQ_CV_BUILD --host=arm-xilinx-linux-gnueabi --enable-shared
make
make install


cd $Cur_Dir/libpng-1.5.14
./configure --prefix=$ZYNQ_CV_BUILD --host=arm-xilinx-linux-gnueabi --with-pkgconfigdir=$ZYNQ_CV_BUILD/lib/pkgconfig LDFLAGS=-L$ZYNQ_CV_BUILD/lib CFLAGS=-I$ZYNQ_CV_INSTALL/include
make
make install


cd $Cur_Dir/x264-snapshot-20120528-2245-stable 
./configure --host=arm-linux --cross-prefix=arm-xilinx-linux-gnueabi- --enable-shared --prefix=$ZYNQ_CV_BUILD
make
make install

cd $Cur_Dir/xvidcore/build/generic
./configure --prefix=$ZYNQ_CV_BUILD --host=arm-xilinx-linux-gnueabi --disable-assembly
make
make install


cd $Cur_Dir/tiff-4.0.3
./configure --prefix=$ZYNQ_CV_BUILD --host=arm-xilinx-linux-gnueabi --enable-shared LDFLAGS=-L$ZYNQ_CV_BUILD/lib CFLAGS=-I$ZYNQ_CV_BUILD/include
make
make install



cd $Cur_Dir/ffmpeg-1.2
./configure --prefix=$ZYNQ_CV_BUILD --enable-shared --disable-static --enable-gpl --enable-cross-compile --arch=armv7l --disable-stripping --target-os=linux --enable-libx264 --enable-libxvid --cross-prefix=arm-xilinx-linux-gnueabi- --enable-swscale --extra-cflags=-I$ZYNQ_CV_BUILD/include --extra-ldflags=-L$ZYNQ_CV_BUILD/lib --disable-asm
make
make install

cd $Cur_Dir/opencv-2.4.5
mkdir build
cd build
echo "set( CMAKE_SYSTEM_NAME Linux )" > toolchain.make
echo "set( CMAKE_SYSTEM_PROCESSOR arm )" >> toolchain.make
echo "set( CMAKE_C_COMPILER arm-xilinx-linux-gnueabi-gcc )" >> toolchain.make
echo "set( CMAKE_CXX_COMPILER arm-xilinx-linux-gnueabi-g++ )" >> toolchain.make
echo "set( CMAKE_INSTALL_PREFIX $ZYNQ_CV_BUILD )" >> toolchain.make
echo "set( CMAKE_FIND_ROOT_PATH $ZYNQ_CV_BUILD )" >> toolchain.make
echo "set( CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER )" >> toolchain.make
echo "set( CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY )" >> toolchain.make
echo "set( CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY )" >> toolchain.make
cmake -D CMAKE_TOOLCHAIN_FILE=toolchain.make -D BUILD_opencv_nonfree=OFF $Cur_Dir/opencv-2.4.5
#cmake-gui
#apt-get install cmake-qt-gui
ccmake . 
cp -r -f $ZYNQ_CV_BUILD/lib/* $Cur_Dir/opencv-2.4.5/build/lib
#cp -r -f $ffmpeg_dir/lib/* $Cur_Dir/release/lib
make
make install
cd $Cur_Dir
