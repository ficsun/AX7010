.. opencvstd documentation master file, created by
   sphinx-quickstart on Mon Feb 14 00:30:43 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to opencv documentation!
================================

.. toctree::
   :maxdepth: 2

   modules/refman.rst
   android/refman.rst
   doc/user_guide/user_guide.rst
   doc/tutorials/tutorials.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
